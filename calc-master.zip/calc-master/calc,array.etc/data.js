module.exports = {
    posts:
    [
        {
            name: 'thing',
            url: 'https://google.com/',
            text: 'text',
            comments: [
                {text: 'commentv1'},
                {text: 'commentv2'},
                {text: 'commentv3'},
            ],
        },

    ],
};
